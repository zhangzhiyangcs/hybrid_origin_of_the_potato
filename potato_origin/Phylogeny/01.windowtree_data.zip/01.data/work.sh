#!/bin/bash
#SBATCH -J wrf
#SBATCH --comment=WRF
#SBATCH -n 10
#SBATCH -N 1
#SBATCH -p xhacnormalb
~/miniconda3/bin/ParaFly -c $1  -CPU 10
