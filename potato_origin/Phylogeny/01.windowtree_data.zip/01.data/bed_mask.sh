bedtools maskfasta -fi chr01.fa -fo chr01_repeat.fa -bed new_chr01.bed
bedtools maskfasta -fi chr02.fa -fo chr02_repeat.fa -bed new_chr02.bed
