cd chr01/chr01.fa ; ls *fa |awk '{print "sed -i 's/N/-/g' "$_}' >sed.sh; sbatch ../work.sh sed.sh; cd ../../
cd chr02/chr02.fa ; ls *fa |awk '{print "sed -i 's/N/-/g' "$_}' >sed.sh; sbatch ../work.sh sed.sh; cd ../../
