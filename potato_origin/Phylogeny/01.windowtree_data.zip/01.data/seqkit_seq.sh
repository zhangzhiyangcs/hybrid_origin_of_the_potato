path=../
for chr in {01..02};do
    cd 'chr'${chr} && ls  ./chr${chr}'_bed'/*bed | sed '$d' | sed 's/\.\/chr'${chr}'_bed\///'  > chr${chr}.list
    for bed in `less chr${chr}.list`; do
        echo "seqkit subseq --bed chr${chr}_bed/${bed} ${path}chr_repeat.${chr}.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr${chr}.fa/${bed}.fa" >>para_seqkit.sh;
    done
    cd ..
done
