iqtree -quiet -s chr01.fa/chr01_001.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr01.iqtree/chr01_001.bed
iqtree -quiet -s chr01.fa/chr01_002.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr01.iqtree/chr01_002.bed
iqtree -quiet -s chr01.fa/chr01_003.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr01.iqtree/chr01_003.bed
