sed -i s/N/-/g chr01_001.bed.fa
sed -i s/N/-/g chr01_002.bed.fa
sed -i s/N/-/g chr01_003.bed.fa
