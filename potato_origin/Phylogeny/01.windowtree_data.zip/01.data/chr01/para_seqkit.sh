seqkit subseq --bed chr01_bed/chr01_001.bed ../chr_repeat.01.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr01.fa/chr01_001.bed.fa
seqkit subseq --bed chr01_bed/chr01_002.bed ../chr_repeat.01.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr01.fa/chr01_002.bed.fa
seqkit subseq --bed chr01_bed/chr01_003.bed ../chr_repeat.01.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr01.fa/chr01_003.bed.fa
