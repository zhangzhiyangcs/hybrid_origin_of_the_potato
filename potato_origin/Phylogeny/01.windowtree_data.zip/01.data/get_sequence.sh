cd chr01; cp ../work.sh ./; sbatch work.sh para_seqkit.sh; cd ..
cd chr02; cp ../work.sh ./; sbatch work.sh para_seqkit.sh; cd ..
