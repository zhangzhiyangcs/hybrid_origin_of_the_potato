
for chr in {01..02};do 
mkdir 'chr'${chr} && cd 'chr'${chr}
mkdir 'chr'${chr}'.fa' && mkdir 'chr'${chr}'_bed' && cd 'chr'${chr}'_bed' && cp ../../'chr'${chr}_win.id ./
split -a 3 -d -l 1 chr${chr}_win.id chr${chr}_ && rm chr*_000
for bed in $(ls chr${chr}_*);do
	for sp in $(cat ../../sample.ID);do
		sed 's/Solanum_tuberosumDM/'${sp}'/g' $bed >> $bed.bed
	done
done
cd ../../
done
