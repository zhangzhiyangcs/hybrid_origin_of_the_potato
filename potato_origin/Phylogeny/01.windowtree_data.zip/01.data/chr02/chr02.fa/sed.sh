sed -i s/N/-/g chr02_001.bed.fa
sed -i s/N/-/g chr02_002.bed.fa
sed -i s/N/-/g chr02_003.bed.fa
