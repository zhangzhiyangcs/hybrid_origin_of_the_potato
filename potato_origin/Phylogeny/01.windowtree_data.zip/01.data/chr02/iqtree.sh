iqtree -quiet -s chr02.fa/chr02_001.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr02.iqtree/chr02_001.bed
iqtree -quiet -s chr02.fa/chr02_002.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr02.iqtree/chr02_002.bed
iqtree -quiet -s chr02.fa/chr02_003.bed.fa -m GTR -nt 4 -bb 1000 -o Solanum_incanum  -pre chr02.iqtree/chr02_003.bed
