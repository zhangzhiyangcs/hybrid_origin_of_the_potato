seqkit subseq --bed chr02_bed/chr02_001.bed ../chr_repeat.02.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr02.fa/chr02_001.bed.fa
seqkit subseq --bed chr02_bed/chr02_002.bed ../chr_repeat.02.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr02.fa/chr02_002.bed.fa
seqkit subseq --bed chr02_bed/chr02_003.bed ../chr_repeat.02.fa |sed   -r  's/_[0-9]+-[0-9]+:.//' >chr02.fa/chr02_003.bed.fa
